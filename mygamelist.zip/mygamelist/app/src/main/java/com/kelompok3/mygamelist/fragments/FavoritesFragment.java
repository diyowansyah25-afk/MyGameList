package com.kelompok3.mygamelist.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.adapters.GameAdapter;
import com.kelompok3.mygamelist.db.DatabaseHelper;
import com.kelompok3.mygamelist.models.Game;

import java.util.ArrayList;
import java.util.List;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerView;
    private GameAdapter gameAdapter;
    private List<Game> favoriteGameList;
    private DatabaseHelper dbHelper;
    private TextView tvEmptyFavorites;

    private GameAdapter.OnGameListener gameListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof GameAdapter.OnGameListener) {
            gameListener = (GameAdapter.OnGameListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement GameAdapter.OnGameListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_favorites);
        tvEmptyFavorites = view.findViewById(R.id.tv_empty_favorites);
        dbHelper = new DatabaseHelper(getContext());
        favoriteGameList = new ArrayList<>();

        setupRecyclerView();
        loadFavoriteGames();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadFavoriteGames();
    }

    private void setupRecyclerView() {
        gameAdapter = new GameAdapter(getContext(), favoriteGameList, gameListener);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(gameAdapter);
    }

    private void loadFavoriteGames() {
        favoriteGameList = dbHelper.getFavoriteGames();

        if (favoriteGameList.isEmpty()) {
            tvEmptyFavorites.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmptyFavorites.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            gameAdapter.updateData(favoriteGameList);
        }
    }
}
