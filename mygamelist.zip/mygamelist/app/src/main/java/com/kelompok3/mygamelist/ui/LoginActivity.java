package com.kelompok3.mygamelist.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.db.DatabaseHelper;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dbHelper = new DatabaseHelper(this);

        dbHelper.checkAndPopulateInitialData();

        sharedPreferences = getSharedPreferences("MyGameListPrefs", MODE_PRIVATE);


        boolean isLoggedIn = sharedPreferences.getBoolean("IS_LOGGED_IN", false);
        if (isLoggedIn) {

            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
            return;
        }


        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        tvRegister = findViewById(R.id.tv_register);

        btnLogin.setOnClickListener(v -> loginUser());

        tvRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void loginUser() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username dan password tidak boleh kosong", Toast.LENGTH_SHORT).show();
            return;
        }


        if (dbHelper.checkUser(username, password)) {

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("IS_LOGGED_IN", true);


            editor.putString("LOGGED_IN_USERNAME", username);


            editor.apply();

            Toast.makeText(this, "Login berhasil!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
        } else {

            Toast.makeText(this, "Username atau password salah", Toast.LENGTH_SHORT).show();
        }
    }
}

