package com.kelompok3.mygamelist.fragments; // PASTIKAN PACKAGE INI BENAR

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.adapters.GameAdapter;
import com.kelompok3.mygamelist.db.DatabaseHelper;
import com.kelompok3.mygamelist.models.Game;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private GameAdapter gameAdapter;
    private List<Game> gameList;
    private DatabaseHelper dbHelper;
    private TextView tvEmpty;

    private GameAdapter.OnGameListener gameListener;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof GameAdapter.OnGameListener) {
            gameListener = (GameAdapter.OnGameListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement GameAdapter.OnGameListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_home);
        tvEmpty = view.findViewById(R.id.tv_empty_home);

        dbHelper = new DatabaseHelper(getContext());
        gameList = new ArrayList<>();

        setupRecyclerView();
        loadAllGames();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAllGames();
    }

    private void setupRecyclerView() {
        gameAdapter = new GameAdapter(getContext(), gameList, gameListener);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(gameAdapter);
    }

    private void loadAllGames() {
        gameList = dbHelper.getAllGames();
        if (gameList.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            gameAdapter.updateData(gameList);
        }
    }
}
