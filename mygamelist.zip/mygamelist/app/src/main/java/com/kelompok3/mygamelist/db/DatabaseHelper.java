package com.kelompok3.mygamelist.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.kelompok3.mygamelist.models.Game;
import com.kelompok3.mygamelist.utils.GameDataUtil;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;

    private static final String DATABASE_NAME = "GameList.db";

    private static final String TABLE_USERS = "users";
    private static final String TABLE_GAMES = "games";

    private static final String KEY_USER_ID = "id";
    private static final String KEY_USER_USERNAME = "username";
    private static final String KEY_USER_PASSWORD = "password";

    private static final String KEY_GAME_ID = "id";
    private static final String KEY_GAME_TITLE = "title";
    private static final String KEY_GAME_GENRE = "genre";
    private static final String KEY_GAME_DESCRIPTION = "description";
    private static final String KEY_GAME_RATING = "rating";
    private static final String KEY_GAME_IS_FAVORITE = "is_favorite";
    private static final String KEY_GAME_IMAGE_RES_ID = "image_res_id";

    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_USER_USERNAME + " TEXT UNIQUE,"
            + KEY_USER_PASSWORD + " TEXT" + ")";

    private static final String CREATE_TABLE_GAMES = "CREATE TABLE " + TABLE_GAMES + "("
            + KEY_GAME_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_GAME_TITLE + " TEXT,"
            + KEY_GAME_GENRE + " TEXT,"
            + KEY_GAME_DESCRIPTION + " TEXT,"
            + KEY_GAME_RATING + " REAL,"
            + KEY_GAME_IS_FAVORITE + " INTEGER,"
            + KEY_GAME_IMAGE_RES_ID + " INTEGER" + ")"; // Tipe data diubah ke INTEGER

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_GAMES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GAMES);

        onCreate(db);
    }


    public void checkAndPopulateInitialData() {
        if (getGamesCount() == 0) {
            List<Game> initialGames = GameDataUtil.getInitialGames();
            for (Game game : initialGames) {
                addGameInternal(this.getWritableDatabase(), game);
            }
        }
    }

    private int getGamesCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String countQuery = "SELECT * FROM " + TABLE_GAMES;
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }
    private void addGameInternal(SQLiteDatabase db, Game game) {
        ContentValues values = new ContentValues();
        values.put(KEY_GAME_TITLE, game.getTitle());
        values.put(KEY_GAME_GENRE, game.getGenre());
        values.put(KEY_GAME_DESCRIPTION, game.getDescription());
        values.put(KEY_GAME_RATING, game.getRating());
        values.put(KEY_GAME_IS_FAVORITE, game.isFavorite() ? 1 : 0);
        values.put(KEY_GAME_IMAGE_RES_ID, game.getImageResId());

        db.insert(TABLE_GAMES, null, values);
    }



    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER_USERNAME, username);
        values.put(KEY_USER_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }


    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {KEY_USER_ID};

        String selection = KEY_USER_USERNAME + " = ?" + " AND " + KEY_USER_PASSWORD + " = ?";

        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);

        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }


    public List<Game> getAllGames() {
        List<Game> gameList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_GAMES;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);


        if (cursor.moveToFirst()) {
            do {
                Game game = new Game(
                        cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_GENRE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_DESCRIPTION)),
                        cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_GAME_RATING)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_IS_FAVORITE)) == 1,
                        cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_IMAGE_RES_ID)) // Mengambil int
                );
                gameList.add(game);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return gameList;
    }


    public List<Game> getFavoriteGames() {
        List<Game> gameList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_GAMES + " WHERE " + KEY_GAME_IS_FAVORITE + " = 1";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Game game = new Game(
                        cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_GENRE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_DESCRIPTION)),
                        cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_GAME_RATING)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_IS_FAVORITE)) == 1,
                        cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_IMAGE_RES_ID))
                );
                gameList.add(game);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return gameList;
    }


    public Game getGame(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GAMES,
                new String[]{KEY_GAME_ID, KEY_GAME_TITLE, KEY_GAME_GENRE, KEY_GAME_DESCRIPTION, KEY_GAME_RATING, KEY_GAME_IS_FAVORITE, KEY_GAME_IMAGE_RES_ID},
                KEY_GAME_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        Game game = new Game(
                cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_TITLE)),
                cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_GENRE)),
                cursor.getString(cursor.getColumnIndexOrThrow(KEY_GAME_DESCRIPTION)),
                cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_GAME_RATING)),
                cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_IS_FAVORITE)) == 1,
                cursor.getInt(cursor.getColumnIndexOrThrow(KEY_GAME_IMAGE_RES_ID))
        );
        cursor.close();
        db.close();
        return game;
    }


    public int updateGame(Game game) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_GAME_RATING, game.getRating());
        values.put(KEY_GAME_IS_FAVORITE, game.isFavorite() ? 1 : 0);


        int result = db.update(TABLE_GAMES, values, KEY_GAME_ID + " = ?",
                new String[]{String.valueOf(game.getId())});
        db.close();
        return result;
    }
}

