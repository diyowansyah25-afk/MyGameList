package com.kelompok3.mygamelist.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.db.DatabaseHelper;
import com.kelompok3.mygamelist.models.Game;

public class DetailFragment extends Fragment {


    public static final String ARG_GAME_ID = "game_id";

    private ImageView ivDetailImage;
    private TextView tvTitle, tvGenre, tvDescription;
    private RatingBar rbDetailRating;
    private CheckBox cbFavorite;
    private Button btnSaveChanges;

    private DatabaseHelper dbHelper;
    private Game currentGame;
    private int gameId;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new DatabaseHelper(getContext());
        // Ambil ID game dari arguments
        if (getArguments() != null) {
            gameId = getArguments().getInt(ARG_GAME_ID);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detail, container, false);

        ivDetailImage = view.findViewById(R.id.iv_detail_image);
        tvTitle = view.findViewById(R.id.tv_detail_title);
        tvGenre = view.findViewById(R.id.tv_detail_genre);
        tvDescription = view.findViewById(R.id.tv_detail_description);
        rbDetailRating = view.findViewById(R.id.rb_detail_rating);
        cbFavorite = view.findViewById(R.id.cb_detail_favorite);
        btnSaveChanges = view.findViewById(R.id.btn_save_changes);

        loadGameDetails();

        btnSaveChanges.setOnClickListener(v -> saveChanges());

        return view;
    }

    private void loadGameDetails() {
        currentGame = dbHelper.getGame(gameId);

        if (currentGame != null) {

            ivDetailImage.setImageResource(currentGame.getImageResId());
            tvTitle.setText(currentGame.getTitle());
            tvGenre.setText(currentGame.getGenre());
            tvDescription.setText(currentGame.getDescription());
            rbDetailRating.setRating(currentGame.getRating());
            cbFavorite.setChecked(currentGame.isFavorite());
        }
    }

    private void saveChanges() {
        if (currentGame != null) {

            float newRating = rbDetailRating.getRating();
            boolean isFavorite = cbFavorite.isChecked();

            currentGame.setRating(newRating);
            currentGame.setFavorite(isFavorite);


            int rowsAffected = dbHelper.updateGame(currentGame);

            if (rowsAffected > 0) {
                Toast.makeText(getContext(), "Perubahan disimpan", Toast.LENGTH_SHORT).show();

                getActivity().getSupportFragmentManager().popBackStack();
            } else {
                Toast.makeText(getContext(), "Gagal menyimpan", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
