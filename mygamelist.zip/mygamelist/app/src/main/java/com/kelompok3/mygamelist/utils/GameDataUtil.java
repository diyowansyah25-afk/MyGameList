package com.kelompok3.mygamelist.utils;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.models.Game;

import java.util.ArrayList;
import java.util.List;

public class GameDataUtil {

    public static List<Game> getInitialGames() {
        List<Game> gameList = new ArrayList<>();


        gameList.add(new Game(
                0,
                "Cyberpunk 2077",
                "RPG",
                "Game open-world RPG di Night City...",
                0.0f,
                false,
                R.drawable.cyberpunk2077
        ));

        gameList.add(new Game(
                0,
                "The Witcher 3",
                "RPG",
                "Kisah Geralt of Rivia mencari Ciri...",
                0.0f,
                false,
                R.drawable.thewitcher3
        ));

        gameList.add(new Game(
                0,
                "Red Dead Redemption 2",
                "Action-Adventure",
                "Kisah Arthur Morgan di akhir era koboi...",
                0.0f,
                false,
                R.drawable.rdr
        ));


        gameList.add(new Game(
                0,
                "GTA V",
                "Action-Adventure",
                "Game open-world di Los Santos...",
                0.0f,
                false,
                R.drawable.gta
        ));

        gameList.add(new Game(
                0,
                "Elden Ring",
                "Action-RPG",
                "Game souls-like open-world dari FromSoftware...",
                0.0f,
                false,
                R.drawable.eldenring
        ));

        gameList.add(new Game(
                0,
                "Valorant",
                "Tactical FPS",
                "Game tembak-tembakan 5v5 berbasis karakter...",
                0.0f,
                false,
                R.drawable.valorant
        ));

        gameList.add(new Game(
                0,
                "Strinova",
                "Anime Tactical FPS",
                "Game tembak-tembakan 5v5 berbasis anime...",
                0.0f,
                false,
                R.drawable.strinova
        ));

        gameList.add(new Game(
                0,
                "Spiderman 2",
                "Action-Adventure",
                "Spiderman jaring-jaring...",
                0.0f,
                false,
                R.drawable.spiderman2
        ));



        return gameList;
    }
}

