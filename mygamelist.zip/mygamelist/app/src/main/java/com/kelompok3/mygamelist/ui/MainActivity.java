package com.kelompok3.mygamelist.ui;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.models.Game;
import com.kelompok3.mygamelist.adapters.GameAdapter;
import com.kelompok3.mygamelist.fragments.DetailFragment;
import com.kelompok3.mygamelist.fragments.FavoritesFragment;
import com.kelompok3.mygamelist.fragments.HomeFragment;
import com.kelompok3.mygamelist.fragments.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements GameAdapter.OnGameListener {

    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);

        if (savedInstanceState == null) {
            loadFragment(new HomeFragment(), "HOME");
        }
    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;
                    String tag = "";

                    int itemId = item.getItemId();
                    if (itemId == R.id.navigation_home) {
                        selectedFragment = new HomeFragment();
                        tag = "HOME";
                    } else if (itemId == R.id.navigation_favorites) {
                        selectedFragment = new FavoritesFragment();
                        tag = "FAVORITES";
                    } else if (itemId == R.id.navigation_profile) {
                        selectedFragment = new ProfileFragment();
                        tag = "PROFILE";
                    }

                    if (selectedFragment != null) {
                        loadFragment(selectedFragment, tag);
                        return true;
                    }
                    return false;
                }
            };


    private void loadFragment(Fragment fragment, String tag) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment, tag)
                .commit();
    }

    @Override
    public void onGameClick(Game game) {

        DetailFragment detailFragment = new DetailFragment();


        Bundle args = new Bundle();
        args.putInt(DetailFragment.ARG_GAME_ID, game.getId());
        detailFragment.setArguments(args);


        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, detailFragment)
                .addToBackStack(null)
                .commit();
    }
}
