package com.kelompok3.mygamelist.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.kelompok3.mygamelist.R;
import com.kelompok3.mygamelist.models.Game;

import java.util.List;

public class GameAdapter extends RecyclerView.Adapter<GameAdapter.GameViewHolder> {

    private List<Game> gameList;
    private Context context;

    private OnGameListener listener;


    public GameAdapter(Context context, List<Game> gameList, OnGameListener listener) {
        this.context = context;
        this.gameList = gameList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public GameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_game, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GameViewHolder holder, int position) {

        Game game = gameList.get(position);


        holder.tvTitle.setText(game.getTitle());
        holder.tvGenre.setText(game.getGenre());
        holder.rbRating.setRating(game.getRating());


        holder.ivPoster.setImageResource(game.getImageResId());

        holder.itemView.setOnClickListener(v -> {
            listener.onGameClick(game);
        });
    }

    @Override
    public int getItemCount() {
        return gameList.size();
    }


    public void updateData(List<Game> newGameList) {
        if (gameList != null) {
            gameList.clear();
            gameList.addAll(newGameList);
            notifyDataSetChanged();
        }
    }


    class GameViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPoster;
        TextView tvTitle, tvGenre;
        RatingBar rbRating;

        public GameViewHolder(@NonNull View itemView) {
            super(itemView);

            ivPoster = itemView.findViewById(R.id.iv_game_poster);
            tvTitle = itemView.findViewById(R.id.tv_game_title);
            tvGenre = itemView.findViewById(R.id.tv_game_genre);
            rbRating = itemView.findViewById(R.id.rb_game_rating);
        }
    }


    public interface OnGameListener {
        void onGameClick(Game game);
    }
}